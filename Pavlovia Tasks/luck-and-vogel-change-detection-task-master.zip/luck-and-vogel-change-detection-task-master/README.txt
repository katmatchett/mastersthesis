Luck & Vogel Change Detection Task
-------------------------------------

The experiment:

	In this task participants are required to judge whether the presented stimuli are the same or different. The stimuli are presented consecutively with a mask inbetween. This experiment is based on experiment by Luck & Vogel (1997). This experiment differs from Luck & Vogel (1997) in the following ways:
 - number of trials
 - this experiment only uses square stimuli, to see the full range of different visual stimuli used by Luck & Vogel (1997) see the reference provided below.

Analysing your data:

	Data is stored in the excel file produced by PsychoPy in the data folder. response.corr column includes data from experimental trials. 1 represents correct response and 0 reperesents incorrect response.

References:
	Luck, S.J., Vogel, E.K. (1997). The capacity of visual working memory for features and conjunctions. Nature, 390:279�281. doi: 10.1038/36846.